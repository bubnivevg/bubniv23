export interface TickerProps {}
