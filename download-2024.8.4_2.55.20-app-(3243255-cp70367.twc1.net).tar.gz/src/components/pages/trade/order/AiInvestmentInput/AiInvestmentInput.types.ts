export interface AiInvestmentInputProps {}
