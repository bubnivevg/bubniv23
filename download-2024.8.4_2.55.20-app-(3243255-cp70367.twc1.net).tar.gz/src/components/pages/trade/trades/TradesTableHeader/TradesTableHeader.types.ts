export interface TradesTableHeaderProps {}
