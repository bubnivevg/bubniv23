import { Trade } from "../Trades.types";

export interface TradeRowProps {
  trade: Trade;
}
