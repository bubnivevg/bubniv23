export { PostsSlider } from "./PostsSlider";
