import { PostProps } from "./PostPagetypes";

const PostBase = ({}: PostProps) => {
  return <></>;
};

export const PostPage = PostBase;
