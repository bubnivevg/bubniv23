export interface PostCardProps {
  post: BlogPost;
}
