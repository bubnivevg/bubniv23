export interface TradeInfoProps {
  ticket?: SupportTicket;
  isSupport: boolean;
}
