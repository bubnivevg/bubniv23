export interface TicketInformationProps {
  ticket?: SupportTicket;
  isSupport: boolean;
}
