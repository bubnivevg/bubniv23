export interface OrderProductListAdminProps {
 
}