export interface BarCodeProps {}
