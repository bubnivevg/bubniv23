export { BarCode } from "./BarCode";
