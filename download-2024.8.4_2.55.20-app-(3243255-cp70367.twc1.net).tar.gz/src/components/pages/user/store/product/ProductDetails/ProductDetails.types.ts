export interface ProductDetailsProps {}
