export { ProductDetails } from "./ProductDetails";
