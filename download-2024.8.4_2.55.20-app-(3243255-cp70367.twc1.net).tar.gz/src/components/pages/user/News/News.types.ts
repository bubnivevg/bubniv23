export interface NewsProps {
 
}