export interface FiatDepositAmountProps {}
