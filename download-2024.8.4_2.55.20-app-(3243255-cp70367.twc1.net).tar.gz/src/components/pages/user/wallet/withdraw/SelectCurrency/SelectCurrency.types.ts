export interface SelectCurrencyProps {}
