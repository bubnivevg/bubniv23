export interface SelectWalletTypeProps {}
