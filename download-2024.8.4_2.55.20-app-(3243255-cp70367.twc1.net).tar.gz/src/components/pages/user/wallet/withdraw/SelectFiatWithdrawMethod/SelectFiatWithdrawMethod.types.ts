export interface SelectFiatDepositMethodProps {}
