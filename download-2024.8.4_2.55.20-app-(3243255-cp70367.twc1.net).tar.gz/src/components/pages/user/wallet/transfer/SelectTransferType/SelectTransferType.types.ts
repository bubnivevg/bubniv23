export interface SelectTransferTypeProps {
 
}