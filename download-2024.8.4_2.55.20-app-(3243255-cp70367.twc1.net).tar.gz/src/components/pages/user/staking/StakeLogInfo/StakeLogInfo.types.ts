export interface StakingPoolInfoProps {}
