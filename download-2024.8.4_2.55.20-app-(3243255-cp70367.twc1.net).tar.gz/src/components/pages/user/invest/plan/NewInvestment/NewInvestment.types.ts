export interface NewInvestmentProps {}
