export { NewInvestment } from "./NewInvestment";
