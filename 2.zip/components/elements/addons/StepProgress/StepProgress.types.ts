export interface StepProgressProps {}
