export interface LoadingRowProps {
  columnConfig;
  canDelete;
  isCrud;
  hasActions;
}
