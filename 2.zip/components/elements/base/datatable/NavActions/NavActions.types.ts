export interface NavActionsProps {
  navAction?: any;
  navActionsSlot?: React.ReactNode;
}
