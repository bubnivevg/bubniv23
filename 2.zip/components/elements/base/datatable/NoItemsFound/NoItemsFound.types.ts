export interface NoItemsFoundProps {
  cols: number;
}
