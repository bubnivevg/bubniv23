export interface PageHeaderProps {
  title: string;
  BackPath?: string;
  children?: React.ReactNode;
}
