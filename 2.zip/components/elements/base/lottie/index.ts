export { Lottie } from "./Lottie";
