export interface ObjectTableProps {}
