export interface TabProps {
  value: string;
  label: string;
  tab: string;
  setTab: (value: string) => void;
  color?: string;
}
