export interface DisplayTotalsProps {}
