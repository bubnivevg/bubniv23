export interface TickSizeSelectorProps {}
