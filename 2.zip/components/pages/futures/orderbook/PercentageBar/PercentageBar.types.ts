export interface PercentageBarProps {}
