export interface CompactOrderInputProps {}
