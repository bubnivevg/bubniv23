export interface SearchBarProps {}
