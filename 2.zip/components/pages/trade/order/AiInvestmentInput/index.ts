export { AiInvestmentInput } from "./AiInvestmentInput";
