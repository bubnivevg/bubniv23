export interface BinaryNavProps {}
