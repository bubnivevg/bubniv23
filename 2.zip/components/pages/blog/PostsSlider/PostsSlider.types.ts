export interface PostsSliderProps {
  content: BlogPost[];
}
