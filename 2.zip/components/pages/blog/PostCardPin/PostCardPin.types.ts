export interface PostCardPinProps {
  post: BlogPost;
}
