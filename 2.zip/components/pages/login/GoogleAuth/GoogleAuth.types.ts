export interface GoogleAuthProps {
 
}