export { Faq } from "./Faq";
