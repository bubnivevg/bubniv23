export interface ReferralTreeProps {}
