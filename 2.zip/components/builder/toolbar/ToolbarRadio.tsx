import React from 'react'

export const ToolbarRadio = () => {
  return <label />
}
