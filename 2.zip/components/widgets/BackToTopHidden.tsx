import React from "react";

const BackToTopHidden = () => {
  return <div></div>;
};

export default BackToTopHidden;
