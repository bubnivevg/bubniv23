export interface HeaderProps {
  modelName: string;
  postTitle?: string;
}
