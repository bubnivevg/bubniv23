export interface WalletChartProps {}
