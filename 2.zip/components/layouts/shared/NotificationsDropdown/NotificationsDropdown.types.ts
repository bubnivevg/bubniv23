export interface NotificationsDropdownProps {}
