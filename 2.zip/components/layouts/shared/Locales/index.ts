export { Locales } from "./Locales";
