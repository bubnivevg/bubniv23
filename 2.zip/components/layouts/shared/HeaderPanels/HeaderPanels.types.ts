export interface HeaderPanelsProps {}
