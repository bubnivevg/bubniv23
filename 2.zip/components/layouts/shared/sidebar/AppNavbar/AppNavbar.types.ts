export interface AppNavbarProps {
  fullwidth?: boolean;
  horizontal?: boolean;
  nopush?: boolean;
  sideblock?: boolean;
  collapse?: boolean;
}
