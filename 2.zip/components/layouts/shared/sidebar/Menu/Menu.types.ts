export interface MenuProps {
  float?: boolean;
  sideblock?: boolean;
  collapse?: boolean;
}
