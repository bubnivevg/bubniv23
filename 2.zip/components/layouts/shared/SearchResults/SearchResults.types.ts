export interface SearchResultsProps {
  id: string;
  searchTerm: string;
}
